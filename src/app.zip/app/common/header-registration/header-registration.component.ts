import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-registration',
  templateUrl: './header-registration.component.html',
  styleUrls: ['./header-registration.component.css']
})
export class HeaderRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
